BOT_TOKEN = "7592268930:AAHq9te6dZJg9612K_OIbi_MLkX8eLi7c9I"
CHAT_ID = "6205753959"
MONITOR_PATH = "D:\Music Station"  # 👈 Your folder path
HASH_DB_FILE = "data/hashes.json"
