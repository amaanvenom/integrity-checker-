from main.monitor import start_monitoring

if __name__ == "__main__":
    start_monitoring()
